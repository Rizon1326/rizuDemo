import React, { useState } from "react";

const ImageUploader = () => {
  const [file, setFile] = useState(null);
  const [album, setAlbum] = useState("");
  const [caption, setCaption] = useState("");
  const [savedMessage, setSavedMessage] = useState("");

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleAlbumChange = (e) => {
    setAlbum(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("file", file);
    formData.append("album", album);

    try {
      const response = await fetch("http://localhost:8000/upload", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      setCaption(data.caption);
      setSavedMessage("Caption saved successfully!");

    } catch (error) {
      console.error("Error:", error);
      setSavedMessage("Error generating caption or saving it.");
    }
  };

  return (
    <div>
      <h1>Image Uploader</h1>
      <form onSubmit={handleSubmit}>
        <input type="file" onChange={handleFileChange} />
        <input type="text" placeholder="Album Name" onChange={handleAlbumChange} />
        <button type="submit">Upload Image</button>
      </form>
      {caption && <p>Caption: {caption}</p>}
      {savedMessage && <p>{savedMessage}</p>}
    </div>
  );
};

export default ImageUploader;
