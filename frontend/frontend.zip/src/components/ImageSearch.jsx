import React, { useState } from "react";

const ImageSearch = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);

  const handleSearchQueryChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSearch = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(`http://localhost:8000/search?query=${searchQuery}`);
      const results = await response.json();
      setSearchResults(results);
    } catch (error) {
      console.error("Error searching captions:", error);
    }
  };

  return (
    <div>
      <h1>Search Images</h1>
      <form onSubmit={handleSearch}>
        <input type="text" placeholder="Enter search query..." onChange={handleSearchQueryChange} />
        <button type="submit">Search</button>
      </form>

      {searchResults.length > 0 && (
        <div>
          <h3>Search Results</h3>
          <ul>
            {searchResults.map((result, index) => {
              const { imageName, imageUrl, caption } = result.caption;
              const similarityScore = typeof result.similarity === "number" ? result.similarity.toFixed(2) : "N/A";

              return (
                <li key={index}>
                  <p>{imageName} - {caption} (Similarity: {similarityScore})</p>
                  <img src={imageUrl} alt={caption} style={{ width: "200px", height: "auto" }} />
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ImageSearch;
