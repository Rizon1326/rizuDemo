import React from "react";
import ImageUploader from "./components/ImageUploader";
import ImageSearch from "./components/ImageSearch";

function App() {
  return (
    <div>
      <ImageUploader />
      <ImageSearch />
    </div>
  );
}

export default App;
